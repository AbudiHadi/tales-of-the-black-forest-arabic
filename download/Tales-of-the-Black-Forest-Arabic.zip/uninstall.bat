@echo off
rem Tales of the Black Forest - Arabic translation by Abdullah Hadi: UNINSTALL
rem Double-click this file. It puts back every original file install.bat saved, deletes the files the translation
rem added, and removes the _arabic_backup folder. The game is then exactly as it was.
setlocal
set "AR_BAT=%~f0"
set "AR_ARG=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:AR_BAT,[Text.Encoding]::UTF8); $i=$t.LastIndexOf('#==PS=='); iex $t.Substring($i)"
echo.
pause
exit /b
#==PS==
$ErrorActionPreference = 'Stop'
$GameName = 'Tales of the Black Forest'
function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }
function Fail($m) { Say ''; Say "[X] $m" 'Red'; exit 1 }

function Find-Game {
    $a = "$env:AR_ARG".Trim().Trim('"').Trim('\')
    if ($a -and (Test-Path -LiteralPath $a) -and (Test-Path -LiteralPath (Join-Path $a 'Game.exe'))) { return $a }
    $steam = @()
    foreach ($k in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
        if ($p.SteamPath) { $steam += $p.SteamPath }
        if ($p.InstallPath) { $steam += $p.InstallPath }
    }
    $libs = @()
    foreach ($s in $steam | Select-Object -Unique) {
        $libs += $s
        $vdf = Join-Path $s 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s+"([^"]+)"')) {
                $libs += ($m.Groups[1].Value -replace '\\\\', '\')
            }
        }
    }
    foreach ($l in $libs | Select-Object -Unique) {
        $g = Join-Path $l "steamapps\common\$GameName"
        if (Test-Path (Join-Path $g '_arabic_backup\backup.json')) { return $g }
    }
    Say 'The game folder was not found automatically.' 'Yellow'
    Say 'Drag the game folder (the one that contains Game.exe) into this window, then press Enter:' 'Yellow'
    $g = (Read-Host '>').Trim().Trim('"')
    if ($g -and (Test-Path (Join-Path $g 'Game.exe'))) { return $g }
    Fail "Game.exe was not found in: $g"
}

Say "$GameName - Arabic translation: uninstall" 'Cyan'
Say '----------------------------------------------------------------'
$game = Find-Game
Say "Game folder: $game" 'Green'
$bk = Join-Path $game '_arabic_backup'
$state = Join-Path $bk 'backup.json'
if (-not (Test-Path $state)) {
    Fail 'No _arabic_backup\backup.json in this folder: the translation was not installed with install.bat. In Steam: right-click the game -> Properties -> Installed Files -> Verify integrity of game files.'
}
$running = Get-Process -Name 'Game' -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($game, [StringComparison]::OrdinalIgnoreCase) }
if ($running) { Fail 'The game is running. Close it, then run uninstall.bat again.' }
$st = Get-Content $state -Raw -Encoding UTF8 | ConvertFrom-Json
# check first: every saved original is there, so the restore cannot stop half way
foreach ($rel in @($st.replaced)) {
    if ($rel -and -not (Test-Path (Join-Path $bk ($rel -replace '/', '\')))) { Fail "The backup is incomplete ($rel is missing). Use Steam's Verify integrity of game files instead." }
}
$n = 0
foreach ($rel in @($st.replaced)) {
    if (-not $rel) { continue }
    $dst = Join-Path $game ($rel -replace '/', '\')
    Copy-Item -LiteralPath (Join-Path $bk ($rel -replace '/', '\')) -Destination $dst -Force
    $n++
}
$d = 0
foreach ($rel in @($st.added)) {
    if (-not $rel) { continue }
    $p = Join-Path $game ($rel -replace '/', '\')
    if (Test-Path $p) { Remove-Item -LiteralPath $p -Force; $d++ }
}
Remove-Item -LiteralPath $bk -Recurse -Force
Say ''
Say ("DONE: {0} original files restored, {1} added files removed. The game is back to the original." -f $n, $d) 'Green'
