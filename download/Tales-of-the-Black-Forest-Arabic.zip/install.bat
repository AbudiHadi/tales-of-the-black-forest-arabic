@echo off
rem Tales of the Black Forest - Arabic translation by Abdullah Hadi: INSTALL
rem Double-click this file. It finds the game, backs up the original files it replaces, copies the Arabic files and
rem checks every copied file. Undo at any time with uninstall.bat.
setlocal
set "AR_BAT=%~f0"
set "AR_MODE=install"
set "AR_ARG=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText($env:AR_BAT,[Text.Encoding]::UTF8); $i=$t.LastIndexOf('#==PS=='); iex $t.Substring($i)"
echo.
pause
exit /b
#==PS==
$ErrorActionPreference = 'Stop'
$Version = '1.0.0'
$GameName = 'Tales of the Black Forest'
$Root = Split-Path -Parent $env:AR_BAT
function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }
function Fail($m) { Say ''; Say "[X] $m" 'Red'; Say 'Nothing more was changed.' 'Red'; exit 1 }

function Find-Game {
    $a = "$env:AR_ARG".Trim().Trim('"').Trim('\')
    if ($a -and (Test-Path -LiteralPath $a) -and (Test-Path -LiteralPath (Join-Path $a 'Game.exe'))) { return $a }
    $steam = @()
    foreach ($k in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        $p = Get-ItemProperty $k -ErrorAction SilentlyContinue
        if ($p.SteamPath) { $steam += $p.SteamPath }
        if ($p.InstallPath) { $steam += $p.InstallPath }
    }
    $libs = @()
    foreach ($s in $steam | Select-Object -Unique) {
        $libs += $s
        $vdf = Join-Path $s 'steamapps\libraryfolders.vdf'
        if (Test-Path $vdf) {
            foreach ($m in [regex]::Matches([IO.File]::ReadAllText($vdf), '"path"\s+"([^"]+)"')) {
                $libs += ($m.Groups[1].Value -replace '\\\\', '\')
            }
        }
    }
    foreach ($l in $libs | Select-Object -Unique) {
        $g = Join-Path $l "steamapps\common\$GameName"
        if (Test-Path (Join-Path $g 'Game.exe')) { return $g }
    }
    Say 'The game folder was not found automatically.' 'Yellow'
    Say 'Drag the game folder (the one that contains Game.exe) into this window, then press Enter:' 'Yellow'
    $g = (Read-Host '>').Trim().Trim('"')
    if ($g -and (Test-Path (Join-Path $g 'Game.exe'))) { return $g }
    Fail "Game.exe was not found in: $g"
}

Say "$GameName - Arabic translation v$Version (Abdullah Hadi)" 'Cyan'
Say '----------------------------------------------------------------'
$src = Join-Path $Root 'www'
$sums = Join-Path $Root 'SHA256SUMS.txt'
if (-not (Test-Path (Join-Path $src 'data\System.json')) -or -not (Test-Path $sums)) {
    Fail 'The "www" folder or SHA256SUMS.txt is missing next to install.bat. Extract the WHOLE zip first, then run install.bat from the extracted folder.'
}
# 1) the package itself is complete and unmodified
$files = @()
foreach ($line in [IO.File]::ReadAllLines($sums, [Text.Encoding]::UTF8)) {
    if ($line -notmatch '^([0-9a-f]{64}) \*(www/.+)$') { continue }
    $rel = $Matches[2]; $want = $Matches[1]
    $p = Join-Path $Root ($rel -replace '/', '\')
    if (-not (Test-Path $p)) { Fail "Missing from the package: $rel (extract the whole zip again)" }
    if ((Get-FileHash $p -Algorithm SHA256).Hash.ToLower() -ne $want) { Fail "Damaged in the package: $rel (download the zip again)" }
    $files += [pscustomobject]@{ Rel = $rel; Sha = $want }
}
if ($files.Count -eq 0) { Fail 'SHA256SUMS.txt lists no files.' }
Say ("Package checked: {0} files." -f $files.Count) 'Green'

# 2) the game
$game = Find-Game
Say "Game folder: $game" 'Green'
if (-not (Test-Path (Join-Path $game 'www\data\System.json'))) { Fail 'This folder has no www\data: it is not the game folder.' }
$running = Get-Process -Name 'Game' -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path.StartsWith($game, [StringComparison]::OrdinalIgnoreCase) }
if ($running) { Fail 'The game is running. Close it, then run install.bat again.' }

# 3) backup of every original this package replaces (kept across re-installs and updates of the translation)
$bk = Join-Path $game '_arabic_backup'
$state = Join-Path $bk 'backup.json'
if (Test-Path $state) { $st = Get-Content $state -Raw -Encoding UTF8 | ConvertFrom-Json } else { $st = [pscustomobject]@{ replaced = @(); added = @() } }
$replaced = [System.Collections.Generic.List[string]]::new(); $st.replaced | ForEach-Object { if ($_) { $replaced.Add($_) } }
$added = [System.Collections.Generic.List[string]]::new(); $st.added | ForEach-Object { if ($_) { $added.Add($_) } }
foreach ($f in $files) {
    if ($replaced.Contains($f.Rel) -or $added.Contains($f.Rel)) { continue }
    $dst = Join-Path $game ($f.Rel -replace '/', '\')
    if (Test-Path $dst) {
        $b = Join-Path $bk ($f.Rel -replace '/', '\')
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $b) | Out-Null
        Copy-Item -LiteralPath $dst -Destination $b -Force
        $replaced.Add($f.Rel)
    } else {
        $added.Add($f.Rel)
    }
}
New-Item -ItemType Directory -Force -Path $bk | Out-Null
[IO.File]::WriteAllText($state, ([pscustomobject]@{ game = $GameName; version = $Version; replaced = $replaced; added = $added } | ConvertTo-Json -Depth 3), [Text.UTF8Encoding]::new($false))
Say ("Backup: {0} original files saved in _arabic_backup." -f $replaced.Count) 'Green'

# 4) copy + check every copied file
foreach ($f in $files) {
    $from = Join-Path $Root ($f.Rel -replace '/', '\')
    $dst = Join-Path $game ($f.Rel -replace '/', '\')
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
    Copy-Item -LiteralPath $from -Destination $dst -Force
    if ((Get-FileHash $dst -Algorithm SHA256).Hash.ToLower() -ne $f.Sha) { Fail "Could not write $($f.Rel) (is the game folder read-only?)" }
}
Say ''
Say ("DONE: the Arabic translation is installed ({0} files checked)." -f $files.Count) 'Green'
Say 'Start the game normally: the text is in Arabic. To undo, run uninstall.bat.' 'Green'
