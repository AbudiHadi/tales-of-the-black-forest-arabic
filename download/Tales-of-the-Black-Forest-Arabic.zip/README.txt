Tales of the Black Forest — Arabic translation, v1.0.0
Translation: Abdullah Hadi (عبدالله هادي)

=============================================
     About this translation
=============================================

- Complete Arabic text for the game: dialogue, choices, menus and settings,
  items and their descriptions, floating texts, and every image with writing
  in it: the logo, chapter and ending cards, the instructions, the poster and
  the note, the end credits, and the station and shop signs on the maps.
- The whole interface is right-to-left: text, menus, and the character
  portrait in dialogue.
- The translation is joint work between AI and human review: every line was
  translated, then independently reviewed before it was accepted.
- All engine work (right-to-left rendering, fonts, images, build and install
  tooling) by Lexara (formerly RTL Forge).
- Font: Almarai.

=============================================
     Automatic install (one minute)
=============================================

1) Close the game.
2) Extract the WHOLE zip into any folder (the Desktop, for example).
   Do not extract it inside the game folder.
3) Double-click install.bat.
   - It finds the game in Steam by itself. If it does not, drag the game
     folder (the one with Game.exe) into the window and press Enter.
   - It saves a copy of every original file it replaces in the
     _arabic_backup folder inside the game folder, then copies the Arabic
     files and checks every one of them.
4) Start the game as usual: the text is in Arabic right away
   (this game has no language menu).

If Windows SmartScreen appears: click "More info", then "Run anyway".

=============================================
     Manual install (alternative)
=============================================

1) Close the game.
2) In Steam: right-click the game -> Manage -> Browse local files.
3) Copy the www folder from the zip into the game folder and choose
   "Replace the files" when asked.
   (Keep a copy of the original www folder first if you want to go back
   without Steam.)

=============================================
     Uninstall / rollback
=============================================

- Installed with install.bat: run uninstall.bat. It puts back every original
  file and deletes the two files the translation added: the game is exactly
  as it was.
- Or in Steam: Properties -> Installed Files -> Verify integrity of game
  files.

=============================================
     Notes
=============================================

- Built for the Steam version of the game (build 23320703).
- A game update may switch some text back to English: run install.bat again
  after the update. If the update changed the game's text, wait for an
  updated translation.
- Do not combine this translation with other mods that change game files.

=============================================
     Rights
=============================================

This translation is the work of Abdullah Hadi. Do not redistribute it or
credit it to anyone else.
