//=============================================================================
// ArabicRTL.js — Arabic right-to-left presentation for Tales of the Black Forest
//=============================================================================
/*:
 * @plugindesc Arabic RTL: shaped text, right-to-left layout, mirrored UI. Load LAST.
 * @author Abdullah Hadi
 *
 * @help
 * Text is stored logical (plain Arabic). Chromium's canvas shapes Arabic and runs the
 * bidi algorithm per drawText call, but RPG Maker draws messages one character at a
 * time, which breaks the joining. This plugin:
 *  - lays out text as RUNS (same style, contiguous) and draws each run in one call,
 *    right-aligned and mirrored about the window contents (x' = width - x - w);
 *  - redraws the current line on every revealed character in the message window, so
 *    the typewriter effect keeps the letters joined;
 *  - does its own bidi: each line is cut into pieces that need no reordering, placed
 *    right-to-left and drawn left-aligned (the canvas never reorders or aligns Arabic);
 *  - mirrors the message bust, the custom menus (item / save / settings / quit),
 *    the autosave toast and the floating "infotext" words.
 */
var ArabicRTL = ArabicRTL || {};
(function () {
'use strict';
var RTL_CHARS = /[֐-ࣿיִ-﷿ﹰ-﻾]/;
// format characters never measured or drawn: bidi embeddings/isolates (laid out by us) and U+200B
var CONTROLS = /[​‪-‮⁦-⁩]/g;
ArabicRTL.hasRtl = function (s) { return typeof s === 'string' && RTL_CHARS.test(s); };

//-----------------------------------------------------------------------------
// Our own bidi + layout. Owner QA 2026-11-14 («سماء where is أ»): the game's Chromium 65 drew an RTL string
// containing spaces wider than it aligned it, so a line drifted right while it typed and lost its first letters.
// So the canvas is never asked to reorder or align Arabic: each line is cut into pieces that need no bidi (an
// Arabic word, a Latin/number group, one neutral character), ordered right-to-left here (UAX#9 W4/W5/W7, N1/N2,
// L2, L4 mirroring, RTL paragraph), measured piece by piece and drawn left-aligned at computed x.
//-----------------------------------------------------------------------------
var MIRROR = {'(': ')', ')': '(', '[': ']', ']': '[', '{': '}', '}': '{', '<': '>', '>': '<',
    '«': '»', '»': '«', '‹': '›', '›': '‹'};
var LTR_CHARS = /[A-Za-zÀ-ʯͰ-ϿЀ-ӿ぀-ヿ㐀-鿿가-힯Ａ-Ｚａ-ｚ]/;
function bidiClass(c) {
    if (c === '‌' || c === '‍') return 'R';
    if (/[0-9٠-٩۰-۹０-９]/.test(c)) return 'EN';
    if (c === '،') return 'N';
    if (RTL_CHARS.test(c)) return 'R';
    if (LTR_CHARS.test(c)) return 'L';
    return 'N';
}
// Visual pieces, left to right: [{t: text to draw, ltr: bool}]
ArabicRTL.visual = function (text) {
    var s = String(text).replace(CONTROLS, ''), n = s.length, c = [], lev = [], i, j, k;
    for (i = 0; i < n; i++) c.push(bidiClass(s[i]));
    for (i = 1; i < n - 1; i++) {   // W4: one separator between two numbers
        if (c[i] === 'N' && /[.,:\/+\-٫٬]/.test(s[i]) && c[i - 1] === 'EN' && c[i + 1] === 'EN') c[i] = 'EN';
    }
    for (i = 0; i < n; i++) {       // W5: terminators next to a number
        if (c[i] === 'N' && /[%٪$#°‰]/.test(s[i]) &&
            ((i > 0 && c[i - 1] === 'EN') || (i < n - 1 && c[i + 1] === 'EN'))) c[i] = 'EN';
    }
    var last = 'R';                 // W7: numbers after Latin are Latin
    for (i = 0; i < n; i++) {
        if (c[i] === 'L' || c[i] === 'R') last = c[i];
        else if (c[i] === 'EN' && last === 'L') c[i] = 'L';
    }
    for (i = 0; i < n; ) {          // N1/N2: neutrals between two Latin are Latin, else RTL (numbers count as R)
        if (c[i] !== 'N') { lev[i] = c[i] === 'R' ? 1 : 2; i++; continue; }
        for (j = i; j < n && c[j] === 'N'; j++) {}
        var lv = (i > 0 && c[i - 1] === 'L' && j < n && c[j] === 'L') ? 2 : 1;
        for (k = i; k < j; k++) lev[k] = lv;
        i = j;
    }
    var units = [];
    for (i = 0; i < n; ) {
        if (lev[i] === 2) {
            for (j = i; j < n && lev[j] === 2; j++) {}
            units.push({t: s.substring(i, j), ltr: true});
        } else if (c[i] === 'R') {
            for (j = i; j < n && lev[j] === 1 && c[j] === 'R'; j++) {}
            units.push({t: s.substring(i, j)});
        } else {
            j = i + 1;
            units.push({t: MIRROR[s[i]] || s[i]});
        }
        i = j;
    }
    return units.reverse();
};

var _Bitmap_measureTextWidth = Bitmap.prototype.measureTextWidth;
Bitmap.prototype.rtlPieces = function (text) {
    var units = ArabicRTL.visual(text), total = 0;
    for (var i = 0; i < units.length; i++) {
        units[i].w = _Bitmap_measureTextWidth.call(this, units[i].t);
        total += units[i].w;
    }
    units.total = total;
    return units;
};
Bitmap.prototype.measureTextWidth = function (text) {
    if (!ArabicRTL.hasRtl(text)) {
        return _Bitmap_measureTextWidth.call(this, typeof text === 'string' ? text.replace(CONTROLS, '') : text);
    }
    return this.rtlPieces(text).total;
};

var _Bitmap_drawText = Bitmap.prototype.drawText;
Bitmap.prototype.drawText = function (text, x, y, maxWidth, lineHeight, align) {
    if (!ArabicRTL.hasRtl(text)) {
        _Bitmap_drawText.call(this, text, x, y, maxWidth, lineHeight, align);
        return;
    }
    this.rtlDrawText(text, x, y, maxWidth, lineHeight, align);
};
// RTL paragraph layout (also for digit-only runs of an Arabic line: «10: » shows its colon on the left).
Bitmap.prototype.rtlDrawText = function (text, x, y, maxWidth, lineHeight, align) {
    if (text === undefined || text === null) return;
    x = Math.floor(x); y = Math.floor(y); lineHeight = Math.floor(lineHeight);
    maxWidth = maxWidth > 0 ? Math.floor(maxWidth) : 0xffffffff;
    var units = this.rtlPieces(text), W = units.total;
    // Too wide for the box: a smaller font, never fillText's maxWidth squeeze. Chromium 65 squeezes each piece
    // differently from our measured layout (owner QA 2026-11-14: the Load header «…تريد التحميل؟» overlapped).
    var savedSize = this.fontSize;
    if (W > maxWidth && maxWidth < 0xffffffff) {
        this.fontSize = Math.max(8, Math.floor(this.fontSize * maxWidth / W));
        units = this.rtlPieces(text); W = units.total;
        while (W > maxWidth && this.fontSize > 8) {
            this.fontSize -= 1;
            units = this.rtlPieces(text); W = units.total;
        }
    }
    var k = W > maxWidth ? maxWidth / W : 1;
    var lx = align === 'center' ? x + (maxWidth - W * k) / 2 : align === 'right' ? x + maxWidth - W * k : x;
    var ty = y + lineHeight - (lineHeight - this.fontSize * 0.7) / 2;
    var pieces = [];
    units.forEach(function (u) {
        var w = u.w * k;
        if (/\S/.test(u.t)) pieces.push({t: u.t, x: lx, mw: k < 1 ? Math.max(1, w) : u.w + 8});
        lx += w;
    });
    var context = this._context, alpha = context.globalAlpha;
    context.save();
    context.font = this._makeFontNameText();
    context.textAlign = 'left';
    context.textBaseline = 'alphabetic';
    context.globalAlpha = 1;
    pieces.forEach(function (p) { this._drawTextOutline(p.t, p.x, ty, p.mw); }, this);
    context.globalAlpha = alpha;
    pieces.forEach(function (p) { this._drawTextBody(p.t, p.x, ty, p.mw); }, this);
    context.restore();
    this.fontSize = savedSize;
    this._setDirty();
};

//-----------------------------------------------------------------------------
// Window_Base: run-based RTL text engine (drawTextEx and the message window).
//-----------------------------------------------------------------------------
function styleOf(b) {
    return [b.fontFace, b.fontSize, b.textColor, b.outlineColor, b.outlineWidth, b.fontItalic ? 1 : 0].join('|');
}
function applyStyle(b, st) {
    var p = st.split('|');
    b.fontFace = p[0]; b.fontSize = Number(p[1]); b.textColor = p[2]; b.outlineColor = p[3];
    b.outlineWidth = Number(p[4]); b.fontItalic = p[5] === '1';
}

Window_Base.prototype.rtlAxis = function () {
    return this.contents ? this.contents.width : 0;
};

Window_Base.prototype.rtlIsLive = function (textState) {
    return this instanceof Window_Message && this._textState === textState;
};

Window_Base.prototype.rtlNormalCharacter = function (textState) {
    var c = textState.text[textState.index++];
    if (!textState._runs) textState._runs = [];
    var st = styleOf(this.contents);
    var run = textState._cur;
    if (!run || run.type !== 'text' || run.y !== textState.y || run.endX !== textState.x || run.st !== st) {
        run = {type: 'text', x0: textState.x, y: textState.y, h: textState.height, text: '', st: st, w: 0};
        textState._runs.push(run);
        textState._cur = run;
    }
    run.text += c;
    run.w = this.contents.measureTextWidth(run.text);
    run.h = Math.max(run.h, textState.height);
    textState.x = run.x0 + run.w;
    run.endX = textState.x;
    if (!this._checkWordWrapMode && this.rtlIsLive(textState)) this.rtlPaintLine(textState, run.y);
};

Window_Base.prototype.processDrawIcon = function (iconIndex, textState) {
    if (!textState._runs) textState._runs = [];
    var w = Window_Base._iconWidth + 4;
    var run = {type: 'icon', icon: iconIndex, x0: textState.x, y: textState.y, h: textState.height, w: w};
    textState._runs.push(run);
    textState._cur = run;
    textState.x += w;
    run.endX = textState.x;
    if (!this._checkWordWrapMode && this.rtlIsLive(textState)) this.rtlPaintLine(textState, run.y);
};

Window_Base.prototype.rtlPaintRun = function (run, M) {
    var b = this.contents;
    var right = M - run.x0;
    if (run.type === 'icon') {
        this.drawIcon(run.icon, right - run.w + 2, run.y + 2);
        return;
    }
    // Edge spaces are laid out by us, not by canvas: under the canvas' LTR paragraph a trailing
    // space would be moved to the visual right (UAX#9 L1) and the gap would land on the wrong side.
    var t = run.text;
    var core = t.replace(/^\s+|\s+$/g, '');
    if (!core) return;
    var save = styleOf(b);
    applyStyle(b, run.st);
    var lead = t.length - t.replace(/^\s+/, '').length;
    var leadW = lead ? b.measureTextWidth(t.substr(0, lead)) : 0;
    var tx = right - leadW;
    // every run of an RTL line is laid out as an RTL paragraph (digits-only runs included)
    b.rtlDrawText(core, tx - run.w - 24, run.y, run.w + 24, run.h, 'right');
    applyStyle(b, save);
};

// Deferred paint (any window): every run of a finished drawTextEx.
Window_Base.prototype.rtlFlush = function (textState) {
    if (!textState._runs || this._checkWordWrapMode) return;
    var M = this.rtlAxis();
    textState._runs.forEach(function (r) { this.rtlPaintRun(r, M); }, this);
    textState._runs = [];
    textState._cur = null;
};

// Live paint (message window): clear a band around line y and redraw, clipped, every run touching it.
Window_Base.prototype.rtlPaintLine = function (textState, y) {
    var b = this.contents, M = this.rtlAxis();
    var runs = textState._runs, minX0 = Infinity, maxEnd = -Infinity, h = 0;
    runs.forEach(function (r) {
        if (r.y === y) { minX0 = Math.min(minX0, r.x0); maxEnd = Math.max(maxEnd, r.x0 + r.w); h = Math.max(h, r.h); }
    });
    if (minX0 === Infinity) return;
    var xL = Math.max(0, Math.floor(M - maxEnd - 14));
    var xR = Math.min(b.width, Math.ceil(M - minX0 + 8));
    var yT = Math.max(0, y - 10), yB = Math.min(b.height, y + h + 10);
    var ctx = b._context;
    b.clearRect(xL, yT, xR - xL, yB - yT);
    ctx.save();
    ctx.beginPath();
    ctx.rect(xL, yT, xR - xL, yB - yT);
    ctx.clip();
    runs.forEach(function (r) {
        if (r.y + r.h + 10 > yT && r.y - 10 < yB) this.rtlPaintRun(r, M);
    }, this);
    ctx.restore();
    b._setDirty();
};

Window_Base.prototype.drawTextEx = function (text, x, y) {
    if (!text) return 0;
    var textState = {index: 0, x: x, y: y, left: x, _runs: []};
    textState.text = this.convertEscapeCharacters(text);
    textState.height = this.calcTextHeight(textState, false);
    this.resetFontSettings();
    while (textState.index < textState.text.length) {
        this.processCharacter(textState);
    }
    this.rtlFlush(textState);
    return textState.x - x;
};

// YEP_MessageCore and Message.js both call this reference at run time.
if (typeof Yanfly !== 'undefined' && Yanfly.Message) {
    Yanfly.Message.Window_Base_processNormalCharacter = Window_Base.prototype.rtlNormalCharacter;
} else {
    Window_Base.prototype.processNormalCharacter = Window_Base.prototype.rtlNormalCharacter;
}

var _Window_Message_newPage = Window_Message.prototype.newPage;
Window_Message.prototype.newPage = function (textState) {
    textState._runs = [];
    textState._cur = null;
    _Window_Message_newPage.call(this, textState);
};

//-----------------------------------------------------------------------------
// GALV_MessageBusts: the bust moves to the opposite side and faces the text.
//-----------------------------------------------------------------------------
if (typeof Sprite_GalvBust !== 'undefined') {
    var _galv_control = Sprite_GalvBust.prototype.controlBitmap;
    Sprite_GalvBust.prototype.controlBitmap = function () {
        _galv_control.call(this);
        if (!this.bitmap || !this.hasBust || !Galv.MB.msgWindow) return;
        var bw = this.bitmap.width;
        var W = (Galv.MB.prio == 1) ? Galv.MB.msgWindow.width : Graphics.boxWidth;
        var left = this.scale.x < 0 ? this.x - bw : this.x;
        var mirroredLeft = W - (left + bw);
        this.scale.x = -this.scale.x;
        this.x = this.scale.x < 0 ? mirroredLeft + bw : mirroredLeft;
    };
}

//-----------------------------------------------------------------------------
// Autosave toast (KJ_Menu): bottom-left instead of bottom-right.
//-----------------------------------------------------------------------------
if (typeof Sprite_AnimationText !== 'undefined') {
    var _sat_init = Sprite_AnimationText.prototype.initialize;
    Sprite_AnimationText.prototype.initialize = function (text, t1, t2, t3, fs, tc, oc, x, y, width, align) {
        if (align === 'right') { x = -x; align = 'left'; }
        _sat_init.call(this, text, t1, t2, t3, fs, tc, oc, x, y, width, align);
    };
}

//-----------------------------------------------------------------------------
// RTL word wrap for plain bitmaps (replaces KJ_Menu's one-glyph-at-a-time drawMutiTexts).
// Lines are right-aligned at endX inside [startX, endX].
//-----------------------------------------------------------------------------
Bitmap.prototype.drawMutiTexts = function (text, startX, startY, endX, lineHeight) {
    if (!text) return startY;
    var maxW = endX - startX, y = startY, self = this;
    String(text).split('\n').forEach(function (para) {
        var words = para.split(' '), line = '';
        words.forEach(function (w) {
            var t = line ? line + ' ' + w : w;
            if (line && self.measureTextWidth(t) > maxW) {
                self.drawText(line, startX, y, maxW, lineHeight, 'right');
                y += lineHeight;
                line = w;
            } else {
                line = t;
            }
        });
        if (line) { self.drawText(line, startX, y, maxW, lineHeight, 'right'); }
        y += lineHeight;
    });
    return y;
};

//-----------------------------------------------------------------------------
// KJ_Menu custom screens, mirrored about the panel (x' = 812 - x - w; the
// panel images ship already mirrored, drawn at the same 90,130).
//-----------------------------------------------------------------------------
var AX = 812;
function mx(x, w) { return AX - x - w; }
function mirrorNote(sprite) {
    if (!sprite) return;
    sprite.anchor.x = 0;
    sprite.x = AX - (562 + 152);
}

if (typeof Scene_Item !== 'undefined' && Scene_Item.prototype.drawAll) {
    var _item_create = Scene_Item.prototype.createMenuSprite;
    Scene_Item.prototype.createMenuSprite = function () {
        _item_create.call(this);
        this._sliderSprite.x = mx(184 - 2, 4);
        mirrorNote(this._noteSprite);
    };
    Scene_Item.prototype.drawAll = function () {
        var c = this.content;
        c.clear();
        var startY = 200, paddingH = 32;
        c.fontSize = 20;
        c.outlineColor = 'rgba(0,0,0,0)';
        c.fontFace = 'UIFont-Heavy';
        var startI = 0, length = 214, slider = 244;
        if (this._data.length > 7) {
            c.fillRect(mx(184, 1), 180, 1, slider, '#bfbfbf');
            var per = this._index / (this._data.length - 1);
            var H = paddingH * this._data.length - 14 - length;
            var deltaH = H * per;
            var deltaI = Math.floor(deltaH / paddingH);
            startI = deltaI;
            startY = startY + deltaI * paddingH - deltaH;
            this._sliderSprite.visible = true;
            this._sliderSprite.y = 180 + (slider - this._sliderSprite.height) * per;
        } else {
            this._sliderSprite.visible = false;
        }
        for (var i = startI; i < startI + 8; i++) {
            var item = this._data[i];
            if (item) {
                c.textColor = (i === this._index) ? '#26a35f' : '#181818';
                c.drawText(item.name, mx(208, 220), startY, 220, 20, 'right');
                startY += paddingH;
            }
        }
        var cur = this._data[this._index];
        if (cur) {
            c.fontSize = 18;
            c.fontFace = 'UIFont-Medium';
            c.textColor = '#0e0e0e';
            c.drawMutiTexts(cur.description, mx(408, 252), 234, mx(408, 252) + 252, 18 + 8);
            // ui_back (Arabic) = [X back | Z confirm] left to right; unusable items show the back half only
            this._noteSprite.setFrame(0, 0, this.hasCommenEvent(cur) ? 152 : 76, 18);
        }
    };
}

if (typeof Scene_File !== 'undefined' && Scene_File.prototype.drawItem) {
    var _file_create = Scene_File.prototype.createMenuSprite;
    Scene_File.prototype.createMenuSprite = function () {
        _file_create.call(this);
        this._sliderSprite.x = mx(184 - 2, 4);
        mirrorNote(this._noteSprite);
    };
    Scene_File.prototype.drawAll = function () {
        var c = this.content;
        c.clear();
        var max = 3, startX = 200, startY = 200, paddingH = 46 + 10, slider = 244;
        c.fontSize = 24;
        c.outlineColor = 'rgba(0,0,0,0)';
        c.fontFace = 'UIFont-Heavy';
        var startI = Math.max(0, this._index - max + 1);
        c.textColor = '#000000';
        c.drawText(this.helpWindowText(), mx(200, 220), 154, 220, 26, 'right');
        startI = Math.max(1, startI);
        if (this._data.length > max) {
            c.fillRect(mx(184, 1), 180, 1, slider, '#bfbfbf');
            var delta = (this.mode() == 'save') ? 1 : 0;
            var per = (this._index - delta) / (this._data.length - 1 - delta);
            this._sliderSprite.visible = true;
            this._sliderSprite.y = 180 + (slider - this._sliderSprite.height) * per;
        } else {
            this._sliderSprite.visible = false;
        }
        c.textColor = '#ffffff';
        this.drawItem(0, startX, startY);
        startY += paddingH;
        for (var i = startI; i < startI + max; i++) {
            this.drawItem(i, startX, startY);
            startY += paddingH;
        }
    };
    Scene_File.prototype.drawItem = function (i, startX, startY) {
        var c = this.content, item = this._data[i];
        var textColor = 'gray';
        if (i == 0 && this.mode() == 'save') textColor = 'gray';
        else if (i == this._index) textColor = '#26a35f';
        else if (item) textColor = '#181818';
        c.fillRect(mx(startX, 460), startY, 460, 46, textColor);
        var text = (i == 0) ? TextManager.preemptive : TextManager.file + i;
        c.fontSize = 24;
        c.drawText(text, mx(startX + 15, 190), startY + 10, 190, 26, 'right');
        if (item) {
            c.fontSize = 20;
            c.drawText(item.mapname, mx(startX + 15 + 120, 200), startY + 10, 200, 26, 'center');
            c.fontSize = 18;
            c.drawText(item.playtime, mx(startX + 15 + 240, 190), startY + 10, 190, 26, 'left');
        }
    };
}

if (typeof Scene_Options !== 'undefined' && Scene_Options.prototype.makeItemList) {
    var _opt_create = Scene_Options.prototype.createMenuSprite;
    Scene_Options.prototype.createMenuSprite = function () {
        _opt_create.call(this);
        mirrorNote(this._noteSprite);
    };
    Scene_Options.prototype.drawAll = function () {
        var c = this.content;
        c.clear();
        c.fontSize = 20;
        c.outlineColor = 'rgba(0,0,0,0)';
        c.fontFace = 'UIFont-Heavy';
        for (var i = 0; i < 5; i++) {
            c.textColor = (i == this._index) ? '#26a35f' : '#181818';
            var text, number;
            if (i == 4) { text = TextManager.escapeStart; number = ''; }
            else { text = TextManager[this._data[i]]; number = ConfigManager[this._data[i]] + '%'; }
            c.drawText(text, mx(298, 200), 202 + 44 * i, 200, 20, 'right');
            c.drawText(number, mx(508, 57), 202 + 44 * i, 57, 20, 'left');
        }
    };
}

if (typeof Scene_GameEnd !== 'undefined' && Scene_GameEnd.prototype.drawAll) {
    var _end_create = Scene_GameEnd.prototype.createMenuSprite;
    Scene_GameEnd.prototype.createMenuSprite = function () {
        _end_create.call(this);
        mirrorNote(this._noteSprite);
    };
    Scene_GameEnd.prototype.drawAll = function () {
        var c = this.content;
        c.clear();
        c.fontSize = KJ.UI.Size1;
        c.outlineColor = 'rgba(0,0,0,0)';
        c.fontFace = 'UIFont-Heavy';
        c.textColor = '#181818';
        c.drawText(TextManager.escapeFailure, mx(240, 390), 240, 390, 24, 'center');
        c.drawText(TextManager.victory, mx(240, 390), 270, 390, 24, 'center');
        c.fontSize = KJ.UI.Size2;
        var right = AX - 250;
        for (var i = 0; i < 3; i++) {
            c.textColor = (i == this._index) ? '#26a35f' : '#181818';
            var width = c.measureTextWidth(this._data[i]);
            c.drawText(this._data[i], right - width, 340, width, 24, 'right');
            right -= (width + KJ.UI.Width);
        }
    };
    // options run right-to-left now: the left key moves to the next option
    Scene_GameEnd.prototype.updateKeyLeft = function () { this.updateKeyMove('left', 1); };
    Scene_GameEnd.prototype.updateKeyRight = function () { this.updateKeyMove('right', -1); };
}

//-----------------------------------------------------------------------------
// MOG_AnimatedText ("infotext"): Arabic is animated per WORD (letters would
// lose their joining). Vertical texts stack the words; horizontal ones run RTL.
//-----------------------------------------------------------------------------
if (typeof InfoText !== 'undefined') {
    var _info_refresh = InfoText.prototype.refreshText;
    InfoText.prototype.refreshText = function () {
        var txt = this.text().toString();
        if (!ArabicRTL.hasRtl(txt)) return _info_refresh.call(this);
        $gameSystem._infoTextData[this._id][0] = false;
        if (this._letters) this.disposeLetters();
        var words = txt.split(' ').filter(function (w) { return w.length; });
        if ($gameSystem._infoTextData[this._id][1] < 0 || words.length === 0) return;
        this._letters = [];
        var fs = this.fontsz();
        var probe = new Bitmap(8, 8);
        probe.fontSize = fs;
        var dir = this.pos() === 0 ? 0 : 1;
        this._tf = 0;
        var widths = words.map(function (w) { return Math.ceil(probe.measureTextWidth(w)); });
        var total = widths.reduce(function (a, b) { return a + b + fs / 3; }, 0);
        var cum = 0;
        for (var i = 0; i < words.length; i++) {
            this._letters[i] = new Sprite(new Bitmap(widths[i] + 20, fs + 20));
            this.setBaseParameters(i, dir, words[i], words.length);
            if (this.pos() === 0) {
                // right-to-left: first word at the right end
                this._letters[i].x = this.posX() + total - cum - widths[i] / 2;
                this._letters[i].org = [this._letters[i].x, this._letters[i].y];
            }
            cum += widths[i] + fs / 3;
            this._letters[i].bitmap.drawText(words[i], 0, 0, this._letters[i].bitmap.width,
                this._letters[i].bitmap.height, 'center');
            this.setEffects(i);
            this.addChild(this._letters[i]);
            dir = dir === 0 ? 1 : 0;
        }
        for (i = 0; i < this._letters.length; i++) this._letters[i].itemMax = this._letters.length - this._tf;
        this._tf = 0;
        if ($gameSystem._infoTextData[this._id][7]) this.loadInfoData();
    };
}

})();
